function predict() {
  const opponent = document.getElementById("opponent").value;

  // توقعات بسيطة مبنية على قوة الرجاء = 70
  let raja_strength = 70;
  let opp_strength = 50;

  if(opponent === "الوداد") opp_strength = 68;
  if(opponent === "الجيش الملكي") opp_strength = 65;
  if(opponent === "برشلونة") opp_strength = 90;
  if(opponent === "بايرن ميونخ") opp_strength = 92;

  let raja_xg = (raja_strength / (raja_strength + opp_strength)) * 2.5;
  let opp_xg = (opp_strength / (raja_strength + opp_strength)) * 2.5;

  let raja_goals = Math.round(raja_xg);
  let opp_goals = Math.round(opp_xg);

  let winner = "تعادل";
  if(raja_goals > opp_goals) winner = "الرجاء سيفوز 💚";
  else if(opp_goals > raja_goals) winner = opponent + " سيفوز 🔴";

  document.getElementById("score").textContent = `الرجاء ${raja_goals} - ${opp_goals} ${opponent}`;
  document.getElementById("win").textContent = `التوقع: ${winner}`;
  document.getElementById("xg").textContent = `xG الرجاء: ${raja_xg.toFixed(2)} | xG الخصم: ${opp_xg.toFixed(2)}`;

  document.getElementById("result").style.display = "block";
}
